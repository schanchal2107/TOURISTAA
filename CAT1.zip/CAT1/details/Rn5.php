<!DOCTYPE html>
<html>
<body>

<h1>The onclick Event</h1>
<img src="../images/redmi 5pro.jpg"></img>

<button onclick="myFunction()">Click me</button>

<p id="demo"></p>

<script>
function myFunction() {
  document.getElementById("demo").innerHTML = "Redmi Note 5 Pro (Gold, 6GB RAM, 64GB Storage) M.R.P.:	? 17,999.00
Price:	? 11,190.00  FREE Delivery. Details
You Save:	? 6,809.00 ";
}
</script>

</body>
</html>
